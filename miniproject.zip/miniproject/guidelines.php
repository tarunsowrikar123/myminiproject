<html>
<head><title>GUIDELINES</title></head>
<style>
body
{
background:#FFCC00;
}
*
{
margin:0;
padding:0;
}
.navigation nav
{
width:100%;
height:60px;
background-color:rgba(0,0,0,0.3);
line-height:60px;
}
.navigation nav ul li
{
list-style-type:none;
display:inline-block;
transition:0.5s all;
}
.navigation nav ul
{
float:right;
margin-right:30px;
}
.navigation nav ul li a
{
font-size:20px;
text-decoration:none;
padding:30px;
color:#FFF;
}
.navigation nav ul li:hover
{
background-color:#FF9900;
}

.lines
{
float:center;
}
.lines ul 
{
    margin:10px;
    padding:10px;
}
</style>
<body>
<div class="navigation">
<nav>
<ul>
<li><a href="guidelines.php">Guidelines</a></li>
<li><a href="about.php">about</a></li>
<li><a href=businfo.php>Bus-information</a></li>
<li><a href="studentlogin.php">HOME</a></li>
</ul>
</nav>
</div>
<br><br>
<h2>GUIDELINES:</h2>
<br><br><div class="lines">
<ul>
<li>Students need to first register themselves with their recieptnumber and create passowrd.</li>
<li>Students need to enter their respective stopnames as mentioned in the bus-information</li>
<li>Students need to check the status of their bus allotment by loggin in</li>
<li>If there is need of updation of stop names student needs to do it soon.</li>
<li>Students need to do it before the deadline mentioned by college administration</li>
</ul>
</div>
</body>
</html>